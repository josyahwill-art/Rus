# NOVA RUST MOBILE – PVP CLIENT V1

A dark red/black Android companion app with:
- Crosshair design preview and color/size/gap/thickness controls
- HUD sample preview with scale and opacity controls
- Graphics and device optimization tips
- Dashboard

## Important limitations
This app does not modify Rust Mobile, read its memory, inject overlays, automate input, or bypass anti-cheat. The crosshair and HUD are previews inside NOVA, not in-game overlays. The dashboard does not claim to read Rust's actual FPS.

## Build the APK from an Android phone (GitHub Actions)
1. Download and extract this ZIP.
2. In your phone browser, sign in to GitHub and create a new public or private repository.
3. Upload the extracted project files and folders to the repository. Keep the `.github/workflows/build-apk.yml` file in that exact location.
4. Open the repository's **Actions** tab.
5. Select **Build NOVA APK**, then choose **Run workflow**. If the workflow has not appeared yet, refresh after uploading the files.
6. Wait for the workflow to finish successfully.
7. Open the completed workflow run, scroll to **Artifacts**, and download `NOVA-RUST-MOBILE-V1-APK`.
8. Extract the artifact ZIP and tap `app-debug.apk` to install.
9. If Android asks, allow your browser or file manager to install unknown apps for this installation, then turn that permission off afterward if you prefer.

## Build locally
Requires JDK 17 and Gradle 8.9 or newer:
`gradle assembleDebug`
APK output:
`app/build/outputs/apk/debug/app-debug.apk`

## Project details
- Package: `com.nova.rustmobile`
- Version: `1.0`
- Minimum Android: 8.0 (API 26)
- Target SDK: 35
