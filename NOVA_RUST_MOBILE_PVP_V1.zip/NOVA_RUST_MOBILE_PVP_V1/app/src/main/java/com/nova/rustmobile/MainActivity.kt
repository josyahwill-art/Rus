package com.nova.rustmobile

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Background = Color(0xFF090909)
private val Panel = Color(0xFF171313)
private val Red = Color(0xFFE53935)
private val Muted = Color(0xFFB8A9A9)
private val White = Color(0xFFF7F2F2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NovaApp() }
    }
}

@Composable
fun NovaApp() {
    var tab by remember { mutableStateOf(0) }
    var crosshairSize by remember { mutableFloatStateOf(18f) }
    var crosshairGap by remember { mutableFloatStateOf(6f) }
    var crosshairThickness by remember { mutableFloatStateOf(2.5f) }
    var crosshairColor by remember { mutableStateOf(Red) }
    var hudScale by remember { mutableFloatStateOf(1f) }
    var hudOpacity by remember { mutableFloatStateOf(0.85f) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Red,
            background = Background,
            surface = Panel,
            onBackground = White,
            onSurface = White
        )
    ) {
        Scaffold(
            containerColor = Background,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF130E0E)) {
                    NavigationBarItem(
                        selected = tab == 0, onClick = { tab = 0 },
                        icon = { Icon(Icons.Default.Dashboard, null) },
                        label = { Text("Home") }
                    )
                    NavigationBarItem(
                        selected = tab == 1, onClick = { tab = 1 },
                        icon = { Icon(Icons.Default.CenterFocusStrong, null) },
                        label = { Text("Crosshair") }
                    )
                    NavigationBarItem(
                        selected = tab == 2, onClick = { tab = 2 },
                        icon = { Icon(Icons.Default.Tune, null) },
                        label = { Text("HUD") }
                    )
                    NavigationBarItem(
                        selected = tab == 3, onClick = { tab = 3 },
                        icon = { Icon(Icons.Default.Speed, null) },
                        label = { Text("Optimize") }
                    )
                }
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
                    .padding(18.dp)
            ) {
                Header()
                Spacer(Modifier.height(18.dp))
                when (tab) {
                    0 -> HomeScreen()
                    1 -> CrosshairScreen(
                        size = crosshairSize, onSize = { crosshairSize = it },
                        gap = crosshairGap, onGap = { crosshairGap = it },
                        thickness = crosshairThickness, onThickness = { crosshairThickness = it },
                        color = crosshairColor, onColor = { crosshairColor = it }
                    )
                    2 -> HudScreen(
                        scale = hudScale, onScale = { hudScale = it },
                        opacity = hudOpacity, onOpacity = { hudOpacity = it }
                    )
                    else -> OptimizeScreen()
                }
            }
        }
    }
}

@Composable
fun Header() {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(46.dp).background(Red, RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.Bolt, contentDescription = null, tint = Color.Black, modifier = Modifier.size(30.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("NOVA", color = White, fontSize = 25.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
            Text("RUST MOBILE  •  PVP COMPANION", color = Muted, fontSize = 10.sp, letterSpacing = 1.2.sp)
        }
        Surface(color = Color(0xFF321414), shape = RoundedCornerShape(8.dp)) {
            Text("V1.0", color = Red, modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp), fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun SectionTitle(title: String, subtitle: String = "") {
    Text(title, color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    if (subtitle.isNotBlank()) {
        Spacer(Modifier.height(4.dp))
        Text(subtitle, color = Muted, fontSize = 12.sp)
    }
}

@Composable
fun InfoCard(title: String, value: String, detail: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Surface(color = Panel, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Red, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(14.dp))
            Column {
                Text(title, color = Muted, fontSize = 12.sp)
                Text(value, color = White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text(detail, color = Muted, fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun HomeScreen() {
    SectionTitle("PVP DASHBOARD", "Your Rust Mobile companion control center")
    Spacer(Modifier.height(14.dp))
    InfoCard("DEVICE DISPLAY REFRESH", "Device-dependent", "This is the screen refresh rate, not Rust's actual FPS.", Icons.Default.PhoneAndroid)
    Spacer(Modifier.height(12.dp))
    InfoCard("CROSSHAIR", "Custom preview", "Tune color, size, spacing and thickness.", Icons.Default.CenterFocusStrong)
    Spacer(Modifier.height(12.dp))
    InfoCard("HUD EDITOR", "Layout presets", "Adjust companion preview scale and opacity.", Icons.Default.Tune)
    Spacer(Modifier.height(12.dp))
    InfoCard("GRAPHICS", "Optimization tips", "Safe Android and in-game settings guidance.", Icons.Default.Bolt)
    Spacer(Modifier.height(18.dp))
    Surface(color = Color(0xFF241010), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(15.dp)) {
            Text("FAIR-PLAY NOTICE", color = Red, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(5.dp))
            Text(
                "NOVA is a companion app. It does not read or change Rust game memory, inject overlays, automate aiming, or bypass anti-cheat.",
                color = White, fontSize = 12.sp
            )
        }
    }
}

@Composable
fun CrosshairScreen(
    size: Float, onSize: (Float) -> Unit,
    gap: Float, onGap: (Float) -> Unit,
    thickness: Float, onThickness: (Float) -> Unit,
    color: Color, onColor: (Color) -> Unit
) {
    SectionTitle("CROSSHAIR STUDIO", "Preview and tune a crosshair design")
    Spacer(Modifier.height(14.dp))
    Surface(color = Color(0xFF101010), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth().height(190.dp)) {
        Box(contentAlignment = Alignment.Center) {
            Canvas(Modifier.size(150.dp)) {
                val cx = this.size.width / 2f
                val cy = this.size.height / 2f
                val arm = size.dp.toPx()
                val space = gap.dp.toPx()
                val stroke = thickness.dp.toPx()
                drawLine(color, Offset(cx - space - arm, cy), Offset(cx - space, cy), stroke, cap = StrokeCap.Round)
                drawLine(color, Offset(cx + space, cy), Offset(cx + space + arm, cy), stroke, cap = StrokeCap.Round)
                drawLine(color, Offset(cx, cy - space - arm), Offset(cx, cy - space), stroke, cap = StrokeCap.Round)
                drawLine(color, Offset(cx, cy + space), Offset(cx, cy + space + arm), stroke, cap = StrokeCap.Round)
            }
        }
    }
    Spacer(Modifier.height(18.dp))
    SliderSetting("Arm length", size, 6f..34f, onSize)
    SliderSetting("Center gap", gap, 2f..16f, onGap)
    SliderSetting("Line thickness", thickness, 1f..6f, onThickness)
    Text("COLOR", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(8.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        listOf(Red, Color.White, Color(0xFF42E66C), Color(0xFF38BDF8), Color(0xFFFFD740)).forEach { c ->
        }
    }
    Text("Select a color using the buttons below.", color = Muted, fontSize = 10.sp)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf(Red, Color.White, Color(0xFF42E66C), Color(0xFF38BDF8), Color(0xFFFFD740)).forEach { c ->
            Button(onClick = { onColor(c) }, colors = ButtonDefaults.buttonColors(containerColor = c), contentPadding = PaddingValues(0.dp), modifier = Modifier.size(42.dp)) {}
        }
    }
    Spacer(Modifier.height(8.dp))
    Text("This crosshair is a design preview inside NOVA; it is not drawn over the game.", color = Muted, fontSize = 11.sp)
}

@Composable
fun SliderSetting(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onValue: (Float) -> Unit) {
    Column {
        Row {
            Text(label, color = White, modifier = Modifier.weight(1f))
            Text(String.format("%.1f", value), color = Red, fontWeight = FontWeight.Bold)
        }
        Slider(value = value, onValueChange = onValue, valueRange = range, colors = SliderDefaults.colors(thumbColor = Red, activeTrackColor = Red))
    }
}

@Composable
fun HudScreen(scale: Float, onScale: (Float) -> Unit, opacity: Float, onOpacity: (Float) -> Unit) {
    SectionTitle("HUD EDITOR", "Adjust NOVA's sample layout preview")
    Spacer(Modifier.height(14.dp))
    Surface(color = Color(0xFF101010), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth().height(220.dp)) {
        Box(Modifier.padding(14.dp)) {
            Text("NOVA HUD PREVIEW", color = Muted, fontSize = 10.sp, modifier = Modifier.align(Alignment.TopStart))
            Surface(color = Red.copy(alpha = opacity), shape = RoundedCornerShape(8.dp), modifier = Modifier.align(Alignment.TopEnd)) {
                Text("STATUS", color = White, fontSize = (10 * scale).sp, modifier = Modifier.padding(8.dp))
            }
            Surface(color = Color(0xFF4A1717).copy(alpha = opacity), shape = RoundedCornerShape(8.dp), modifier = Modifier.align(Alignment.BottomStart)) {
                Text("PVP PANEL", color = White, fontSize = (12 * scale).sp, modifier = Modifier.padding(10.dp))
            }
            Surface(color = Color(0xFF292929).copy(alpha = opacity), shape = RoundedCornerShape(8.dp), modifier = Modifier.align(Alignment.BottomEnd)) {
                Text("INFO", color = White, fontSize = (10 * scale).sp, modifier = Modifier.padding(8.dp))
            }
        }
    }
    Spacer(Modifier.height(18.dp))
    SliderSetting("Preview scale", scale, 0.7f..1.4f, onScale)
    SliderSetting("Preview opacity", opacity, 0.2f..1f, onOpacity)
    Text("These controls change only the NOVA preview, not Rust's in-game HUD.", color = Muted, fontSize = 11.sp)
}

@Composable
fun OptimizeScreen() {
    SectionTitle("GRAPHICS OPTIMIZER", "Safe settings to try on your phone")
    Spacer(Modifier.height(14.dp))
    TipCard("IN RUST SETTINGS", "Start with a lower graphics preset if the game stutters. Increase quality gradually until performance becomes unstable.")
    TipCard("ANDROID", "Close unused apps before playing and keep enough free storage for the game and updates.")
    TipCard("THERMALS", "Avoid playing while the phone is overheating. Heat can cause automatic performance throttling.")
    TipCard("DISPLAY", "Use a refresh-rate setting supported by your phone. A higher display refresh rate does not guarantee higher game FPS.")
    TipCard("BATTERY", "For longer sessions, use a balanced power mode and avoid extreme battery-saver settings while gaming.")
}

@Composable
fun TipCard(title: String, body: String) {
    Surface(color = Panel, shape = RoundedCornerShape(15.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(15.dp)) {
            Text(title, color = Red, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Spacer(Modifier.height(6.dp))
            Text(body, color = White, fontSize = 12.sp)
        }
    }
    Spacer(Modifier.height(10.dp))
}
